
import React from 'react';
import { Link } from 'react-router-dom';
import { FaArrowRight } from 'react-icons/fa';


const ProductCard = ({ product }) => (
  <div className="product-card">
    <Link to={`/product/${product.id}`}>
    <img src={product.image} alt={product.title} />
    <div className='info-top'><h2>{product.title}</h2></div>
    <div className='info-bottom'><span>${product.price}</span>
    <Link to={`/product/${product.id}`}><FaArrowRight /></Link></div>
    </Link>
  </div>
);

export default ProductCard;
