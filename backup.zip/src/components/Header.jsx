
import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => (
  <header>
    <img src="/src/images/logo.png"></img>
    <nav>
      <Link to="/">Inicio</Link>
      <Link to="/">Mi Cuenta</Link>
      <Link to="/">Mis Compras</Link>


    </nav>
  </header>
);

export default Header;
