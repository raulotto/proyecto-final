import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ProductList from '../components/ProductList';
import CategoryFilter from '../components/CategoryFilter';


const Home = () => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get('https://fakestoreapi.com/products');
        setProducts(response.data);
        setFilteredProducts(response.data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  useEffect(() => {
    if (selectedCategory === 'all') {
      setFilteredProducts(products);
    } else {
      setFilteredProducts(products.filter(product => product.category === selectedCategory));
    }
  }, [selectedCategory, products]);

  if (loading) {
    return <div className='loading-sec'>Loading...</div>;
  }

  if (error) {
    return <p>Error: {error}</p>;
  }

   return (
    <div className="flex">
      <div className="w-1/6 sticky top-0 h-screen p-4 bg-gray-100">
        <CategoryFilter selectedCategory={selectedCategory} onSelectCategory={setSelectedCategory} />
      </div>
      <div className="w-5/6 p-4">
        <ProductList products={filteredProducts} />
      </div>
    </div>
  );
};


export default Home;
